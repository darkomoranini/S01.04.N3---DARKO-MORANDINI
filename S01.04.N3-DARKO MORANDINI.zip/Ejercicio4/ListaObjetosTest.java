package Ejercicio4;
import java.util.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ListaObjetosTest {

	@Test
	public void mismoOrden() {
		ArrayList<Object>listaObjetos=new ArrayList<Object>();
		Persona persona = new Persona();
		listaObjetos.add(persona);
		Perro perro = new Perro();
		listaObjetos.add(perro);
		listaObjetos.add("string");
	
		Assertions.assertEquals(persona, listaObjetos.get(0));
		Assertions.assertEquals(perro, listaObjetos.get(1));
		Assertions.assertEquals("string", listaObjetos.get(2));		
		}
	
	@Test
	public void cualquierOrden() {
		ArrayList<Object>listaObjetos=new ArrayList<Object>();
		Persona persona = new Persona();
		listaObjetos.add(persona);
		Perro perro = new Perro();
		listaObjetos.add(perro);
		listaObjetos.add("string");
		ArrayList<Object>listaObjetos1=new ArrayList<Object>();
		listaObjetos1.add(perro);
		listaObjetos1.add(persona);
		listaObjetos1.add("string");
		
		Assertions.assertTrue(listaObjetos.containsAll(listaObjetos1));		
		}
	
	@Test
	public void noDuplicados() {
		ArrayList<Object>listaObjetos=new ArrayList<Object>();
		Persona persona = new Persona();
		listaObjetos.add(persona);
		Perro perro = new Perro();
		listaObjetos.add(perro);
		//listaObjetos.add("string");
		 
		int index = 0;
	        for (Object obj : listaObjetos) {
	            if (obj.equals(perro)) {
	                index++;
	            }
	        }
	        Assertions.assertEquals(1, index);
	    
	        String elementoEliminado = "string";
	        Assertions.assertFalse(listaObjetos.contains(elementoEliminado));
		}	
	}




