package Ejercicio4;

public class Perro {

	public Perro() {
		
	}
}
