package Ejercicio4;

public class Persona {

	public Persona() {
		
	}
}
