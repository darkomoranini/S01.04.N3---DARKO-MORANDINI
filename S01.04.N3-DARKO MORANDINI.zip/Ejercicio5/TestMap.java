package Ejercicio5;

import java.util.HashMap;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TestMap {

	 @Test
	    public void testMapContainKey() {
	        HashMap<String, Integer> listaNumeros = new HashMap<>();
	        
	        listaNumeros.put("Uno", 1);
	        listaNumeros.put("Dos", 2);
	        listaNumeros.put("Tres", 3);
	        
	        Assertions.assertTrue(listaNumeros.containsKey("Dos"));
	    }


}
