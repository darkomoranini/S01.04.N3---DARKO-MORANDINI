package Ejercicio6;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestExcepcion {

	@Test
    public void testArrayIndexOutOfBoundsException() {
        int[] array = {1, 2, 3};

        assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
            int value = array[3];
        });
    }

}
