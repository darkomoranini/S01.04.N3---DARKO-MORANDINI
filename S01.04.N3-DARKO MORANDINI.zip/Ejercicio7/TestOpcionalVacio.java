package Ejercicio7;

import org.junit.Test;
import java.util.Optional;
import static org.junit.Assert.assertFalse;

public class TestOpcionalVacio {

    @Test
    public void testOpcionalVacio() {
        Optional<String> emptyOptional = Optional.empty();
        
        assertFalse(emptyOptional.isPresent());
    }
}