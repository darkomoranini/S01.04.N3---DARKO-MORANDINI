package Ejercicio3;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ArrayIgualesTest {

	@Test
	public void arrayIgualesTest() {
		int[] numeros = {1, 2, 3, 4, 5};
		int[] numeros1 = {1, 2, 3, 4, 5};
		
		Assertions.assertArrayEquals(numeros, numeros1);
		
	}

}
