package Ejercicio1;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class EnterosIgualesTest {

    @Test
    public void testEnterosIguales() {
        int valor1 = 5;
        int valor2 = 5;

        Assertions.assertEquals(valor1, valor2);
    }
    @Test
    public void testEnterosDiferentes() {
        int valor1 = 3;
        int valor2 = 5;

        Assertions.assertNotEquals(valor1, valor2);
    }

}
