package Ejercicio2;

public class Persona {
	
	public Persona() {
		
	}	

}
