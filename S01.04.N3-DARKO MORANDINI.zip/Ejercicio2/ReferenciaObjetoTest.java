package Ejercicio2;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ReferenciaObjetoTest {

	@Test
	public void ReferenciaObjetosIguales() {
		Persona persona = new Persona() ;
		Persona persona1=persona;
		Assertions.assertSame(persona, persona1);
	}

	@Test
	public void ReferenciaObjetosDistintas() {
		Persona persona = new Persona() ;
		Perro perro = new Perro();
		Assertions.assertNotSame(persona, perro);
	}
}
