package Ejercicio2;

public class Perro {

	public Perro() {
		
	}
}
